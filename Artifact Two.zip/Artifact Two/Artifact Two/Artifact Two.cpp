//============================================================================
// Name        : Artifact Two.cpp
// Author      : Kevin Tormey
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Artifact 2 in C++, Ansi-style
//============================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string> // atoi
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

const unsigned int DEFAULT_SIZE = 179;

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Hash Table class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a hash table with chaining.
 */
class HashTable {

private:
    // FIXME (1): Define structures to hold bids
    //Psudeocode Struct is created with 2 variables as well as a node pointer directing each Node to the next node. The variables are a bid of type Bid
    //and a unsigned int key. The Key is used as an identifier while the Bid is the value of said identifier.
    // 3 constructors were created one with default that sets the key value to the MAX possible integer value and the next value to a nullptr value
    // The second constructor needs a Bid value and calls the default constructor running it first before adding the bid value of aBid
    // The third constructor needs both a Bid value and a key value, it calls the constructor requiring a bid value then adds the key value of aKey.
    struct Node
    {
        Bid bid;
        unsigned key;
        Node* next;

        //default constructor
        Node()
        {
            key = UINT_MAX;
            next = nullptr;
        }
        // initialize with a bid
        Node(Bid aBid) : Node()
        {
            bid = aBid;
        }
        // initialize with a bid and a key
        Node(Bid aBid, unsigned aKey) : Node(aBid)
        {
            key = aKey;
        }
    };

    //Vector nodes is created to hold all the nodes of the program then the unsigned int variable tableSize is given the value of DEFAULT_SIZE (assigned at start)
    vector<Node> nodes;

    unsigned tableSize = DEFAULT_SIZE;

    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned size);
    virtual ~HashTable();
    void Insert(Bid bid);
    void PrintAll();
    void Remove(string bidId);
    Bid Search(string bidId);
};

/**
 * Default constructor
 */
HashTable::HashTable() {
    // FIXME (2): Initialize the structures used to hold bids
    // nodes are resized based on the value of tableSize
    nodes.resize(tableSize);
}

HashTable::HashTable(unsigned size)
{
    // nodes are resized based on the value of tableSize but tableSize is set to the provided variable size
    this->tableSize = size;
    nodes.resize(tableSize);
}
/**
 * Destructor
 */
HashTable::~HashTable() {
    // FIXME (3): Implement logic to free storage when class is destroyed
    //Vector function erase is used to delete the nodes from their beginning to end. Erase loops through nodes and deletes values as it goes along.
    nodes.erase(nodes.begin());
}

/**
 * Calculate the hash value of a given key.
 * Note that key is specifically defined as
 * unsigned int to prevent undefined results
 * of a negative list index.
 *
 * @param key The key to hash
 * @return The calculated hash
 */
unsigned int HashTable::hash(int key) {
    // FIXME (4): Implement logic to calculate a hash value
    //Modulus operation is used to determine the location of the value based on the value of tableSize which is the size of the table (predetermined)
    return key % tableSize;
}

/**
 * Insert a bid
 *
 * @param bid The bid to insert
 */
void HashTable::Insert(Bid bid) {
    // FIXME (5): Implement logic to insert a bid
    //A key is created by calling the hash function then the bidId is converted to a string with the built in atoi function converting it into an integer.
    unsigned key = hash(atoi(bid.bidId.c_str()));

    // try and retrieve node using the key
    Node* oldNode = &(nodes.at(key));

    // if no value is found for the key
    if (oldNode == nullptr)
    {
        //Node is constructed using the created key and the provided bid, the new Node was then inserted into the vector with the key as an offset
        Node* newNode = new Node(bid, key);
        nodes.insert(nodes.begin() + key, (*newNode));
    }
    else
    {
        //node found
        //if the node was found and the key value was the max meaning it was not used yet
        //the key, bid and next values are set. Key is set to key, bid is set to bid and next is set to nullptr
        if (oldNode->key == UINT_MAX)
        {
            oldNode->key = key;
            oldNode->bid = bid;
            oldNode->next = nullptr;
        }
        else
        {
            // find the next open node (last one)
            // if the next is not null the while loop will keep iterating over the nodes
            while (oldNode->next != nullptr)
            {
                oldNode = oldNode->next;

            }
            //when nullptr is found a new node is created and assigned to the next pointer
            oldNode->next = new Node(bid, key);
        }
    }
}

/**
 * Print all bids
 */
void HashTable::PrintAll() {
    // FIXME (6): Implement logic to print all bids
    // An auto iterator is used to go through the the hash table nods
    // As it see each bucket the program outputs the bidId, title, amount and fund
    for (auto iter = nodes.begin(); iter != nodes.end(); ++iter)
    {
        cout << iter->bid.bidId << ": " << iter->bid.title << " | " << iter->bid.amount << " | " << iter->bid.fund << endl;
    }
}

/**
 * Remove a bid
 *
 * @param bidId The bid id to search for
 */
void HashTable::Remove(string bidId) {
    // FIXME (7): Implement logic to remove a bid
    // A key is obtained then the erase function is called to remove the key at that index and its value
    unsigned key = hash(atoi(bidId.c_str()));
    nodes.erase(nodes.begin() + key);
}

/**
 * Search for the specified bidId
 *
 * @param bidId The bid id to search for
 */
Bid HashTable::Search(string bidId) {
    Bid bid;

    // FIXME (8): Implement logic to search for and return a bid

    // calculate the key for this bid
    unsigned key = hash(atoi(bidId.c_str()));

    // try and retrieve node using the key
    Node* node = &(nodes.at(key));

    // if no entry found
    // if the node is a nullptr or the node is empty
    if (node == nullptr || node->key == UINT_MAX)
    {
        return bid;
    }

    // if node found that matches key
    // if the node is found and it is not nullptr and the key is not unused and the bidId does not = 0
    if (node != nullptr && node->key != UINT_MAX && node->bid.bidId.compare(bidId) == 0)
    {
        return node->bid;
    }
    // walk the linked list to find the match
    while (node != nullptr)
    {
        // as long as the key is not null or empty if it matches bid is returned otherwise it keeps going until it reaches the end of the while loop
        if (node->key != UINT_MAX && node->bid.bidId.compare(bidId) == 0)
        {
            return node->bid;
        }
        node = node->next;
    }

    return bid;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
        << bid.fund << endl;
    return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, HashTable* hashTable) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            hashTable->Insert(bid);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    //bidKey was changed to searchValue to avoid confusion
    string csvPath, searchValue;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        searchValue = "98109";
        break;
    case 3:
        csvPath = argv[1];
        searchValue = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        searchValue = "98109";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a hash table to hold all the bids
    HashTable* bidTable;

    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  5. Add Bid" << endl;
        cout << "  6. Exit" << endl;
        cout << "Enter choice: ";
        int HasLoaded = 0;
        cin >> choice;

        switch (choice) {

        case 1: // Loads the Bids
            bidTable = new HashTable();

            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadBids(csvPath, bidTable);

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            HasLoaded = 1;
            break;

        case 2: // Prints Bids after loading
            if (HasLoaded == 1)
            {
                bidTable->PrintAll();
            }
            break;

        case 3: // Searches for a specific bid
            ticks = clock();

            bid = bidTable->Search(searchValue);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            }
            else {
                cout << "Bid Id " << searchValue << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 4: // Removes specified bid
            bidTable->Remove(searchValue);
            break;
        case 5: // Adds a new bid (Added Functionality)
            cout << "Enter new bid information in order of ID (Int), Title (String), Fund (String) and then finally Amount (Float): " << endl;
            Bid NewBid;
            int bidID;
            cin >> bidID;
            string bidTitle;
            cin >> bidTitle;
            string bidFund;
            cin >> bidFund;
            float bidAmount;
            cin >> bidAmount;
            NewBid.bidId = bidID;
            NewBid.title = bidTitle;
            NewBid.fund = bidFund;
            NewBid.amount = bidAmount;
            bidTable->Insert(NewBid);
            break;
        }
    }

    cout << "Good bye." << endl;

    return 0;
}

// The enchancement for this project was that I added to the program to allow the function to create your own bids adding them to the system.